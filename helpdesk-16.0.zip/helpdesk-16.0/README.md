
[![Runboat](https://img.shields.io/badge/runboat-Try%20me-875A7B.png)](https://runboat.odoo-community.org/builds?repo=OCA/helpdesk&target_branch=16.0)
[![Pre-commit Status](https://github.com/OCA/helpdesk/actions/workflows/pre-commit.yml/badge.svg?branch=16.0)](https://github.com/OCA/helpdesk/actions/workflows/pre-commit.yml?query=branch%3A16.0)
[![Build Status](https://github.com/OCA/helpdesk/actions/workflows/test.yml/badge.svg?branch=16.0)](https://github.com/OCA/helpdesk/actions/workflows/test.yml?query=branch%3A16.0)
[![codecov](https://codecov.io/gh/OCA/helpdesk/branch/16.0/graph/badge.svg)](https://codecov.io/gh/OCA/helpdesk)
[![Translation Status](https://translation.odoo-community.org/widgets/helpdesk-16-0/-/svg-badge.svg)](https://translation.odoo-community.org/engage/helpdesk-16-0/?utm_source=widget)

<!-- /!\ do not modify above this line -->

# helpdesk

TODO: add repo description.

<!-- /!\ do not modify below this line -->

<!-- prettier-ignore-start -->

[//]: # (addons)

Available addons
----------------
addon | version | maintainers | summary
--- | --- | --- | ---
[helpdesk_mgmt](helpdesk_mgmt/) | 16.0.2.6.1 |  | Helpdesk
[helpdesk_mgmt_project](helpdesk_mgmt_project/) | 16.0.2.1.0 |  | Add the option to select project in the tickets.
[helpdesk_mgmt_rating](helpdesk_mgmt_rating/) | 16.0.1.0.0 |  | This module allows customer to rate the assistance received on a ticket.
[helpdesk_mgmt_timesheet](helpdesk_mgmt_timesheet/) | 16.0.1.5.1 |  | Add HR Timesheet to the tickets for Helpdesk Management.
[helpdesk_motive](helpdesk_motive/) | 16.0.1.0.0 | [![nelsonramirezs](https://github.com/nelsonramirezs.png?size=30px)](https://github.com/nelsonramirezs) [![max3903](https://github.com/max3903.png?size=30px)](https://github.com/max3903) | Keep the motive
[helpdesk_product](helpdesk_product/) | 16.0.1.0.1 |  | Add the option to select product in the tickets.
[helpdesk_type](helpdesk_type/) | 16.0.1.1.0 | [![nelsonramirezs](https://github.com/nelsonramirezs.png?size=30px)](https://github.com/nelsonramirezs) [![max3903](https://github.com/max3903.png?size=30px)](https://github.com/max3903) | Add a type to your tickets

[//]: # (end addons)

<!-- prettier-ignore-end -->

## Licenses

This repository is licensed under [AGPL-3.0](LICENSE).

However, each module can have a totally different license, as long as they adhere to Odoo Community Association (OCA)
policy. Consult each module's `__manifest__.py` file, which contains a `license` key
that explains its license.

----
OCA, or the [Odoo Community Association](http://odoo-community.org/), is a nonprofit
organization whose mission is to support the collaborative development of Odoo features
and promote its widespread use.
